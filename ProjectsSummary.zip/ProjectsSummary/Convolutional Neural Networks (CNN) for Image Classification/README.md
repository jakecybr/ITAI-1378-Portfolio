# Convolutional Neural Networks (CNN) for Image Classification

This lab explored building and training a Convolutional Neural Network (CNN) to classify images of muffins and chihuahuas. The CNN outperformed traditional neural networks in accuracy and efficiency.