# Flappy Bird AI Development with Reinforcement Learning

The capstone project detailed the development of a Flappy Bird AI using reinforcement learning techniques. It utilized tools like PyGame and OpenAI Gym, along with a Deep Q-Network algorithm.