# Support Vector Machines (SVM) and CIFAR-10 Dataset

This lab applied Support Vector Machines (SVMs) to classify images in the CIFAR-10 dataset. It covered concepts such as hyperplanes, support vectors, and kernel functions.