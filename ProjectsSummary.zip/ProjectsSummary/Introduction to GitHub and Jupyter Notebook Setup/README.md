# Introduction to GitHub and Jupyter Notebook Setup

This lab introduced GitHub and Jupyter Notebooks, teaching version control, repository creation, and running example code in the Jupyter environment.