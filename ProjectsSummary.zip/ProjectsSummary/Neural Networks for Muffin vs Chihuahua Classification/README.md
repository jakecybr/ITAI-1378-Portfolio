# Neural Networks for Muffin vs Chihuahua Classification

This lab demonstrated the construction of a neural network for classifying images as either muffins or chihuahuas. Concepts included data preprocessing, network structure, and evaluation metrics.